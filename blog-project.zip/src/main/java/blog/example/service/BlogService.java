package blog.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import blog.example.model.dao.BlogDao;
import blog.example.model.entity.BlogEntity;

@Service
public class BlogService {
	
	@Autowired
	BlogDao blogDao;
	
	//블로그 내용 보존
	public void insert(String blogTitle, String blogImage, String blogComment, Long userId, Long categoryId) {
		blogDao.save(new BlogEntity(blogTitle, blogImage, blogComment, userId, categoryId));
	}
	//유저 블로그 일람
	public List<BlogEntity> selectByAll(){
		return blogDao.findAll();
	}
	
	//블로그 일람
	public List<BlogEntity> selectByUserId(Long userId){
		return blogDao.findByUserId(userId);
	}
	
	//내용 갱신
	public void update(Long blogId, String blogTitle, String blogImage, String blogComment, Long userId, Long categoryId) {
		blogDao.save(new BlogEntity(blogTitle, blogImage, blogComment, userId, categoryId));
	}

	//카테고리 일람
	public List<BlogEntity> selectByCategoryId(Long categoryId){
		return blogDao.findByCategoryId(categoryId);
	}
}
