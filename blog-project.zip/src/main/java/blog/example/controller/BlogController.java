package blog.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import blog.example.service.BlogService;
import blog.example.service.UserService;

@Controller
public class BlogController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	BlogService blogService;
}
